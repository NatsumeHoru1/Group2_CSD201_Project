package hashbench.test;

import static hashbench.HashIndex.*;
import static hashbench.test.TestHarness.check;
import static hashbench.test.TestHarness.eq;
import static hashbench.test.TestHarness.test;

import hashbench.HashIndex;
import hashbench.test.Registry.Impl;
import java.util.HashMap;
import java.util.SplittableRandom;

/**
 * Oracle: so với HashMap trên 10^6 thao tác (put/get/remove = 40/40/20), M = 2^12, ba miền khóa ~0,5M / M / 2M.
 * Chỉ cập nhật oracle khi bảng KHÔNG trả FULL. Kiểm tra cả điều kiện FULL đúng/sai (size == M và khóa chưa có).
 */
public final class OracleTest {
    static final int P = 12, M = 1 << P;
    static final long SEED = 20260002L;

    private OracleTest() {}

    public static void runAll(final Impl impl, final long ops) {
        final double[] factors = { 0.5, 1.0, 2.0 };
        for (int i = 0; i < factors.length; i++) {
            final double f = factors[i];
            final boolean offset = (i == 1);          // miền M dùng ánh xạ khóa lớn để phủ bit cao
            test("oracle " + ops + " thao tác, miền = " + f + "M" + (offset ? " (khóa lớn)" : ""),
                 new TestHarness.Body() { public void run() { one(impl, f, offset, ops); } });
        }
    }

    static void one(Impl impl, double factor, boolean offset, long ops) {
        final int domain = (int) (factor * M);
        final long mul = offset ? 1_000_003L : 1L, off = offset ? 12_345_678_901L : 0L;
        HashIndex t = impl.f.create(P);
        HashMap<Long, Integer> ref = new HashMap<Long, Integer>();
        SplittableRandom rng = new SplittableRandom(SEED + (long) (factor * 100));
        long fulls = 0, inserts = 0, updates = 0, removes = 0;

        for (long op = 1; op <= ops; op++) {
            long key = rng.nextInt(domain) * mul + off;
            int r = rng.nextInt(100);
            if (r < 40) {
                int v = rng.nextInt(); if (v == NOT_FOUND) v = 0;
                boolean present = ref.containsKey(key);
                int expect = present ? UPDATED : (ref.size() == M ? FULL : INSERTED);
                int got = t.put(key, v);
                if (got != expect) throw new AssertionError("op " + op + " put(" + key + "): mong " + expect + ", nhận " + got);
                if (got == FULL) fulls++; else { ref.put(key, v); if (got == INSERTED) inserts++; else updates++; }
            } else if (r < 80) {
                Integer e = ref.get(key);
                int exp = e == null ? NOT_FOUND : e;
                int got = t.get(key);
                if (got != exp) throw new AssertionError("op " + op + " get(" + key + "): mong " + exp + ", nhận " + got);
            } else {
                boolean exp = ref.remove(key) != null;
                boolean got = t.remove(key);
                if (got != exp) throw new AssertionError("op " + op + " remove(" + key + "): mong " + exp + ", nhận " + got);
                if (got) removes++;
            }
            if (t.size() != ref.size()) throw new AssertionError("op " + op + ": size " + t.size() + " != " + ref.size());
            if ((op & 0x3FFF) == 0) TestUtil.validate(t);
            if (op % 100_000 == 0) sweep(t, ref, domain, mul, off, op);
        }
        sweep(t, ref, domain, mul, off, ops);
        TestUtil.validate(t);
        // bảo vệ khỏi test "rỗng": phải thật sự chạm trạng thái đầy khi miền > M
        if (factor > 1.0 && ops >= 200_000) check(fulls > 0, "miền " + factor + "M mà chưa bao giờ gặp FULL: oracle không phủ nhánh đầy");
        check(inserts > 0 && removes > 0, "oracle không sinh đủ loại thao tác");
        System.out.println("      (insert=" + inserts + " update=" + updates + " remove=" + removes + " FULL=" + fulls + " size cuối=" + t.size() + ")");
    }

    static void sweep(HashIndex t, HashMap<Long, Integer> ref, int domain, long mul, long off, long op) {
        for (int k = 0; k < domain; k++) {
            long key = k * mul + off;
            Integer e = ref.get(key);
            int exp = e == null ? NOT_FOUND : e;
            if (t.get(key) != exp) throw new AssertionError("quét toàn miền tại op " + op + ": get(" + key + ") sai");
        }
    }
}
